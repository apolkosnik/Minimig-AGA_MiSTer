# Copyright © 2020... Wolfgang Foerster - Inventronik GmbH.
# All rights reserved. No portion of this sourcecode may be  
# reproduced or transmitted in any form by any means, whether
# by electronic, mechanical, photocopying, recording or      
# otherwise, without my written permission.                  
 
#**************************************************************
# Time Information
#**************************************************************

# set_time_format -unit ns -decimal_places 3



#**************************************************************
# Create Clock
#**************************************************************

# create_clock -name CLK -period 100.000 -waveform {0.000 50.000} [get_ports {CLK}]

#create_clock -period 166.600 -name CLK_6MHz [get_ports {CLK_6MHz}]
create_clock -period 125.000 -name CLK_CPU [get_ports {CLK_CPU}]
create_clock -period 62.500 -name CLK_16MHz [get_ports {CLK_16MHz}]

derive_pll_clocks
#derive_pll_clocks -use_net_name
derive_clock_uncertainty

set_clock_groups -exclusive -group {CLK_CPU}
set_clock_groups -exclusive -group {CLK_16MHz}
#set_clock_groups -exclusive -group {CODEC_SCLK}
